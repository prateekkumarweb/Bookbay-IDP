$(document).ready(function(){

    var $login1=$("#login1"),
        $signup1=$("#signup1"),
        $home=$("#home,.home"),
        $nbar=$("#nbar");
        
    $("#login, #mlogin").click(function(){
        $('#searchresult').hide();
        $login1.slideDown(550);
        $signup1.slideUp();
        $home.slideUp();
        //$nbar.slideUp();
        $("#username,#password").val("");
    });
    
    $("#redcross").click(function(){
        $('#searchresult').show('slow');
        $login1.slideUp();
        $home.slideDown("slow");
        //$nbar.slideDown("slow");
    });
    
    $("#signup,#lsignup").click(function(){
        $('#searchresult').hide();
        $signup1.slideDown(550);
        $login1.slideUp();
        $home.slideUp();
        //$nbar.slideUp();
        $("#pname,#pemail,#pspassword,#pscpassword").html("");
        $("#name,#email,#spassword,#scpassword").val("");
    });
    
    $("#suredcross").click(function(){
        $('#searchresult').show('slow');
        $signup1.slideUp();
        $home.slideDown("slow");
        //$nbar.slideDown("slow");
    });

    (function(){
        $("#name").blur(function(){
            if ($(this).val()===""){
                $("#pname").html("This cannot be empty");    
            }
            else{
                $("#pname").html("");
            }
        });
        
        $("#email").blur(function(){
            if ($(this).val()===""){
                $("#pemail").html("This cannot be empty");    
            }
            else{
                $("#pemail").html("");
            }
        });
        
        $("#spassword").blur(function(){
            if ($(this).val()===""){
                $("#pspassword").html("This cannot be empty");    
            }
            else{
                $("#pspassword").html("");
            }
        });
        
        $("#scpassword").blur(function(){
            if ($(this).val()===""){
                $("#pscpassword").html("This cannot be empty");    
            }
            else{
                $("#pscpassword").html("");
            }
        });
    })();

    
});