$(document).ready(function(){
    $("#login").click(function(){
        $("#login1").css("display","block");
        $("#signup1").css("display","none");
        $("#home,.home").css("display","none");
        $("#nbar").css("display","none");
    });
    
    $("#redcross").click(function(){
        $("#login1").css("display","none");
        $("#home,.home").css("display","block");
        $("#nbar").css("display","block");
    });
    
    $("#signup,#lsignup").click(function(){
        $("#signup1").css("display","block");
        $("#login1").css("display","none");
        $("#home,.home").css("display","none");
        $("#nbar").css("display","none");
        $("#pname,#pemail,#pspassword,#pscpassword").html("");
    });
    
    $("#suredcross").click(function(){
        $("#signup1").css("display","none");
        $("#home,.home").css("display","block");
        $("#nbar").css("display","block");
    });
    
    $("#mlogin").click(function(){
        $("#login1").css("display","block");
        $("#signup1").css("display","none");
        $("#nbar").css("display","none");
    });
    
     $("#finalsup").click(function(){
         if($("#name").val()==""){
             $("#pname").html("This cannot be empty");
         }
         
         if($("#email").val()==""){
             $("#pemail").html("This cannot be empty");
         }
         
         if($("#spassword").val()==""){
             $("#pspassword").html("This cannot be empty");
         }
         
         if($("#scpassword").val()==""){
             $("#pscpassword").html("This cannot be empty");
         }
         
        if ($("#spassword").val()!=$("#scpassword").val()){
            $("#mismatch").html("Passwords didn't match");
        }
    });
    
    (function(){
        
        $("#name").blur(function(){
            if ($(this).val()==""){
                $("#pname").html("This cannot be empty");    
            }
            else{
                $("#pname").html("");
            }
        });
        
        $("#email").blur(function(){
            if ($(this).val()==""){
                $("#pemail").html("This cannot be empty");    
            }
            else{
                $("#pemail").html("");
            }
        });
        
        $("#spassword").blur(function(){
            if ($(this).val()==""){
                $("#pspassword").html("This cannot be empty");    
            }
            else{
                $("#pspassword").html("");
            }
        });
        
        $("#scpassword").blur(function(){
            if ($(this).val()==""){
                $("#pscpassword").html("This cannot be empty");    
            }
            else{
                $("#pscpassword").html("");
            }
        });
    })();
});