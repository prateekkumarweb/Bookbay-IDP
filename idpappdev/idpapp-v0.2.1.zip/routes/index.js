var express = require('express');
var router = express.Router();
var crypto = require('crypto');
var mysql = require('mysql');
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME || 'localhost',
  	user     : process.env.RDS_USERNAME || 'root',
  	password : process.env.RDS_PASSWORD || 'pk-mysql-db',
 	port     : process.env.RDS_PORT || '3306',
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err);
});

/* GET home page. */
router.get('/', function(req, res, next) {
    conn.query("create table if not exists books (id varchar(255) primary key, name varchar(255) not null, author varchar(255), course varchar(255), description text, url text not null, pic text, fulltext (id, name, author, course))", function(err, rows, fields){
        if (err) res.send(err)
    })
    next();
});

router.get('/book', function(req, res) {
    var id = req.query.id;
    conn.query("select * from books where id='"+id+"';", function(err, rows, fields){
        res.header("Access-Control-Allow-Origin", "*");
        res.json(rows);
    })
});

router.get('/search', function(req, res) {
    var q = req.query.q;
    conn.query("select * from books where match (id, name, author, course) against (? in natural language mode)",[q] , function(err, rows, fields) {
        res.header("Access-Control-Allow-Origin", "*");
        res.json(rows);
        //res.render('search', {s: rows, q : q});
    });    
});

router.get('/esearch', function(req, res) {
    var q = req.query.q;
    conn.query("select * from books where match (id, name, author, course) against (? in natural language mode with query expansion)",[q] , function(err, rows, fields) {
        res.header("Access-Control-Allow-Origin", "*");
        res.json(rows);
        //res.render('search', {s: rows, q : q});
    });    
});

router.get('/test', function(req, res){
    res.send('test')
})


module.exports = router;
