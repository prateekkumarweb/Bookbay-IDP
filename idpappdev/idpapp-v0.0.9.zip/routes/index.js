var mysql = require('mysql');
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME,
  	user     : process.env.RDS_USERNAME,
  	password : process.env.RDS_PASSWORD,
 	port     : process.env.RDS_PORT,
    database : "idp"
});
conn.connect(function(err){
    if (err) console.log(err);
});
/*
 * GET home page.
 */

exports.index = function(req, res){
    conn.query("create table test ()", function(err, rows, fields) {
        res.render('index');
    });
};
