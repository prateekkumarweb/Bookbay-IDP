function signout() {
    $.removeCookie('user');
    location.reload();
}
$(document).ready(function(){
    if ($.cookie('user')) {
        $.get('/u/signin', {}, function(data, status){
            if (status == 'success') {
                if (data != null || data != '') {
                    $('#signupli').html('<a href="#">'+data.username+'</a>');
                    $('#loginli').html('<a href="#" onclick="signout()">Signout</a>');
                    $('#loginform').html('');
                    $('#signupform').html('');
                }
            } else {
                alert('Unable to connect to server.');
            }
        });
    }
    $('#loginbtn').click(function(){
        var user = $('#username').val();
        var pass = $('#password').val();
        $.post('/u/signin', { username: user, password: pass }, function(data, status){
            if (status == 'success') {
                if (data == null || data == '') {
                    $('#invalidcr').html('Invalid Credentials');
                } else {
                    location.reload();
                }
            } else {
                $('#invalidcr').html('Unable to connect to server.');
            }
        });
    });
    $('#finalsup').click(function(){
        var name = $('#name').val();
        var user = $('#email').val();
        var pass = $('#spassword').val();
        var cpass = $('#scpassword').val();
        $.post('/u/signup', { fullname: name, username: user, password: pass, cpassword: cpass }, function(data, status){
            if (status == 'success') {
                console.log(data);
                if (data.status == true) {
                    $('#mismatch').html(data.error);
                    location.reload();
                } else {
                    $('#mismatch').html(data.error);
                }
            } else {
                $('#mismatch').html('Unable to connect to server.');
            }
        });
    });
});