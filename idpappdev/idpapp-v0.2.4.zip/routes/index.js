var express = require('express');
var router = express.Router();
var crypto = require('crypto');
var mysql = require('mysql');
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME || 'aaywunas67cinm.cyta6fw9verf.us-west-2.rds.amazonaws.com',
  	user     : process.env.RDS_USERNAME || 'root',
  	password : process.env.RDS_PASSWORD || 'pk-mysql-db',
 	port     : process.env.RDS_PORT || '3306',
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err);
});

/* GET home page. */
router.get('/*', function(req, res, next) {
    conn.query("create table if not exists users (username varchar(255) primary key, password varchar(255) not null, fullname varchar(255) not null, verify varchar(64) not null unique)", function(err, rows, fields){
        if (err) res.send(err);
    });
    conn.query("create table if not exists courses (id varchar(255) primary key, name varchar(255) not null, start date not null, end date not null)", function(err, rows, fields){
        if (err) res.send(err);
    });
    conn.query("create table if not exists books (id varchar(255) primary key, name varchar(255) not null, author varchar(255), course varchar(255), description text, url text not null, pic text, userWhoAdded varchar(255), fulltext (id, name, author, course), foreign key (userWhoAdded) references users(username), foreign key (course) references courses(id))", function(err, rows, fields){
        if (err) res.send(err)
    });
    conn.query("create table if not exists userProfile (profilename varchar(255) primary key, fullname varchar(255) not null, foreign key (profilename) references users(username))", function(err, rows, fields){
        if (err) res.send(err);
    });
    conn.query("create table if not exists userCourses (username varchar(255) primary key,  course varchar(255) not null, foreign key (username) references users(username), foreign key (course) references courses(id))", function(err, rows, fields){
        if (err) res.send(err);
    });
    conn.query("create table if not exists commentsOnBooks (username varchar(255) not null, bookid varchar(255) not null, comment text not null, foreign key (username) references users(username), foreign key (bookid) references books(id))", function(err, rows, fields){
        if (err) res.send(err);
    });
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    next();
});

router.get('/book', function(req, res) {
    var id = req.query.id;
    conn.query("select * from books where id='"+id+"';", function(err, rows, fields){
        res.json(rows);
    })
});

router.get('/search', function(req, res) {
    var q = req.query.q;
    conn.query("select * from books where match (id, name, author, course) against (? in natural language mode)",[q] , function(err, rows, fields) {
        res.json(rows);
        //res.render('search', {s: rows, q : q});
    });
});

router.get('/esearch', function(req, res) {
    var q = req.query.q;
    conn.query("select * from books where match (id, name, author, course) against (? in natural language mode with query expansion)",[q] , function(err, rows, fields) {
        res.json(rows);
        //res.render('search', {s: rows, q : q});
    });
});

router.get('/test', function(req, res){
    res.send('test')
})


module.exports = router;
