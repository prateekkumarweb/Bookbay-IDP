$(document).ready(function(){
    if ($.cookie('user')) {
        $.get('/u/signinwithjs', function(data, status){
            $('#signout').html('');
            $('#signin').html(data.username);
        });
    } 
});