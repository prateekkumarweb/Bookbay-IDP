var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var nodemailer = require("nodemailer");
var smtpTransport = nodemailer.createTransport("SMTP",{
    service: "Gmail",
    auth: {
        user: "smartsiteiith@gmail.com",
        pass: "pk@9876543210"
    }
});
var db = require('../config/db');
var conn = mysql.createConnection({
    host     : db.host,
  	user     : db.user,
  	password : db.password,
 	port     : db.port,
    database : db.database
});
conn.connect(function(err){
    if (err) console.log(err);
});

function randomStr(m) {
	var m = m || 64; s = '', r = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	for (var i=0; i < m; i++) { s += r.charAt(Math.floor(Math.random()*r.length)); }
	return s;
}

var crypto = require('crypto'), algorithm = 'aes-256-ctr', password = 'idptwentyfifteensixteensecretkey';
function encrypt(text){
  var cipher = crypto.createCipher(algorithm, password);
  var crypted = cipher.update(text, 'utf8', 'hex');
  crypted += cipher.final('hex');
  return crypted;
}
function decrypt(text){
  var decipher = crypto.createDecipher(algorithm, password);
  var dec = decipher.update(text, 'hex', 'utf8');
  dec += decipher.final('utf8');
  return dec;
}
function hash(text) {
    var h = crypto.createHash('sha256').update(text).digest("hex");
    return h;
}

function verifyUsername(username) {
    var z = username.toUpperCase().split('@');
    var c = (z.length === 1 || (z.length === 2 && z[1] === 'IITH.AC.IN'));
    return [c, z[0]];
}

function isSignin(user, callback) {
    if (user === undefined || user === null) callback(false, []);
    if (typeof(user) === "string") {
        user = decrypt(user)
        user = user.split('username-password');
    }
    var z = verifyUsername(user[0]);
    if (z[0]) {
      conn.query("select * from users where username=? and password=?", [z[1], hash(user[1])], function(err, rows, fields){
          if (err) {
              callback(false, []);
          }
          else if (!rows[0]) {
              callback(false, []);
          }
          else {
              u = {}
              for (var i in rows[0]) {
                  u[i] = rows[0][i];
              }
              callback(true, u);
          }
      });
    } else callback(false, []);
}

function sendEmail(toemail, sub, txt, htm, callback) {
    var mailOptions = {
        from: "Bookbay at IITH <noreply@bookbayatiith.com>", // sender address
        to: toemail, // list of receivers
        subject: sub, // Subject line
        text: txt, // plaintext body
        html: htm // html body
    }
    smtpTransport.sendMail(mailOptions, function(error, response){
        if(error){
            console.log(error);
            callback(false);
        }else{
            console.log("Message sent: " + response.message);
            callback(true);
        }

        // if you don't want to use this transport object anymore, uncomment following line
        //smtpTransport.close(); // shut down the connection pool, no more messages
    });
    
}


//res.header("Access-Control-Allow-Origin", "*");

router.get('/signin', function(req, res){
    isSignin(req.signedCookies.user, function(status, user){
        if (status) {
            res.json(user);
        } else {
            res.clearCookie('user');
            res.send();
        }
    });
});

router.post('/signin', function(req, res){
    userDetails = [req.body.username, req.body.password];
    isSignin(userDetails, function(status, user){
        if (status) {
            res.cookie('user', encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
            res.send(user);
        } else {
            res.send();
        }
    });
})

router.get('/s/signin', function(req, res){
    isSignin(req.signedCookies.user, function(status, user){
        if (status) {
            res.redirect('/u/user/');
        } else {
            res.clearCookie('user');
            res.render('u/signin', {url: req.query.url || '/u/user', msg: '', msgs: ''});
        }
    });
});

router.post('/s/signin', function(req, res) {
    userDetails = [req.body.username, req.body.password];
    isSignin(userDetails, function(status, user){
        if (status) {
            res.cookie('user', encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
            if (req.body.url != '') {
                res.redirect(req.body.url);
            } else {
                res.redirect('/u/user/');
            }
        } else {
            res.render('u/signin', {url: req.body.url || '/u/user', msg: 'Invalid Credentials', msgs: ''});
        }
    });
});

router.post('/s/signup', function(req, res) {
    var fullname = req.body.fullname;
    var username = req.body.username;
    var password = req.body.password;
    var rndm = randomStr();
    if (password != "" && fullname != "" && username != "" ) {
        var z = verifyUsername(username);
        if (z[0]) {
          conn.query("insert into users (fullname, username, password, verify) values (?, ?, ?, ?)", [fullname, z[1], hash(password), rndm], function(err){
              if (err){
                  res.render('u/signin', {url: req.body.url || '/u/user', msg: '', msgs: 'This username is not available'});
              }
              else {
                  res.cookie('user', encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
                  var t = "To verify your account go to http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+" ";
                  var h = "<a href='http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+"'>Click here to verify Account</a>";
                  sendEmail(z[1].toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(a){
                      if (a) {
                          res.redirect(req.body.url);
                      } else {
                          res.render('u/signup');
                      }
                  });
              }
          });
        }
        else res.render('u/signin', {url: req.body.url || '/u/user', msg: '', msgs: 'Invalid Username'});
    } else {
        res.render('u/signin', {url: req.body.url || '/u/user', msg: '', msgs: 'All fields are required'});
    }
    
});

router.post('/signup', function(req, res){
    if (req.signedCookies.user) {
        res.send({status: false, message: 'Signout first'});
    } else {
        var fullname = req.body.fullname;
        var username = req.body.username;
        var password = req.body.password;
        var rndm = randomStr();
        if (password != "" && fullname != "" && username != "" ) {
            var z = verifyUsername(username);
            if (z[0]) {
              conn.query("insert into users (fullname, username, password, verify) values (?, ?, ?, ?)", [fullname, z[1], hash(password), rndm], function(err){
                  if (err){
                      res.send({status: false, message: err});
                  }
                  else {
                      res.cookie('user', encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
                      var t = "To verify your account go to http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+" ";
                      var h = "<a href='http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+"'>Click here to verify Account</a>";
                      sendEmail(z[1].toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(a){
                          
                      });
                      res.send({status: true, message: 'Username signed in'});
                  }
              });
            }
            else res.send({status: false, message: 'Only IITH emails are accepted'});
        } else {
            res.send({status: false, message: 'Passwords do not match'});
        }
    }
});

router.get('/verify/:r', function(req, res){
    var r = req.params.r;
    conn.query("select * from users where verify=?", [r], function(err, rows, fields){
        if (err) res.send("Couldnot verify user. There was a temperory error.");
        else {
            if (rows.length === 0) res.send(404);
            else {
                conn.query("insert into userProfile (profilename, fullname) values (?, ?)", [rows[0].username, rows[0].fullname], function(errr){
                    if (errr) res.redirect("/u/user");
                    else res.send("You have successfully verified your email. <a href='/u/user'>Go to Home</a>");
                });
            }
        }
    });
});

router.post('/signout', function(req, res){
    res.clearCookie('user');
    res.send();
});

router.post('/changepassword', function(req, res){
    isSignin(req.signedCookies.user, function(status, user){
        if (status) {
            var oldpassword = req.body.oldpassword;
            var newpassword = req.body.newpassword;
            var cnewpassword = req.body.cnewpassword;
            if (newpassword != cnewpassword) {
                res.send({status: false, message: 'Passwords do not match'});
            } else if (hash(oldpassword) === user.password) {
                conn.query('UPDATE users SET password=? WHERE username=?', [hash(newpassword), user.username], function(err, rows, fields){
                    if (err) {
                        res.send({status: false, message: 'Try Again later'});
                    } else {
                        res.cookie('user', encrypt(user.username + 'username-password' + newpassword), { signed: true });
                        res.send({status: true, message: 'Password changed'});
                    }
                });
            } else {
                res.send({status: false, message: 'Invalid password'});
            }
        } else {
            res.send({status: false, message: 'User not signed in'});
        }
    });
});


/*router.get('/email',  function(req, res) {
    var mailOptions = {
        from: "Bookbay at IITH <noreply@bookbayatiith.com>", // sender address
        to: "Help <pksingh1023@gmail.com>", // list of receivers
        subject: "Hello", // Subject line
        text: "Hello world", // plaintext body
        html: "<b>Hello world</b>" // html body
    }
    smtpTransport.sendMail(mailOptions, function(error, response){
        if(error){
            console.log(error);
            res.send('failure');
        }else{
            console.log("Message sent: " + response.message);
            res.send('success');
        }

        // if you don't want to use this transport object anymore, uncomment following line
        //smtpTransport.close(); // shut down the connection pool, no more messages
    });
});*/

























function verifyProfile(user, callback) {
    isSignin(user, function(status, us) {
        if(status) {
            conn.query("select * from userProfile where profilename=?", [us.username], function(err, rows, fields){
                if (err) callback(true, false, []);
                else if (rows.length === 0) callback(true, false, us);
                else {
                    callback(true, true, rows[0]);
                }
            });
        } else {
            callback(false, false, []);
        }
    });
}

//profile page scripts starts here
router.get('/user/*', function(req, res, next) {
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    verifyProfile(req.signedCookies.user, function(a, b, user){
        if (a) {
            if (b) next();
            else res.render('u/verify');
        } else res.redirect('/u/s/signin?url=/u' + encodeURI(req.url));
    });
});

router.get('/vemail', function(req, res){
    verifyProfile(req.signedCookies.user, function(a, b, user){
        if (a) {
            if (b) res.send(false);
            else {
                var rndm = user.verify;
                var t = "To verify your account go to http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+" ";
                var h = "<a href='http://idpapp.elasticbeanstalk.com/u/verify/"+rndm+"'>Click here to verify Account</a>";
                sendEmail(user.username.toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(ab){
                    res.send(ab);
                });
            }
        } else res.send(false);
    });
});

router.post('/user/*', function(req, res, next) {
    verifyProfile(req.signedCookies.user, function(a, b, user){
        if (a) {
            if (b) next();
            else res.send(false);
        } else res.send(false);
    });
});

router.post('/user/book/comment', function (req, res) {
    verifyProfile(req.signedCookies.user, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var bookid = req.body.bookid;
            var comment = req.body.comment;
            conn.query("insert into commentsOnBooks (username, bookid, comment) values (?, ?, ?)", [username, bookid, comment], function (err, rows, fields) {
                if (err) {console.log(err); res.send(false);}
                else res.send(true);
            });
        } else res.send(false);
    });
});

router.get('/book/comments', function (req, res) {
    var i = req.query.bookid;
    conn.query("select * from commentsOnBooks where bookid=? order by id DESC", [i], function(err, rows, fields){
        if (err) res.send();
        else res.send(rows);
    });
});

router.get('/book/comment/votesandreplies', function (req, res) {
    var i = req.query.commentid;
    var r = [];
    conn.query("select count(*) as upvotes from votesOnComments where vote=1 and commentid=?", [i], function(err, rows, fields){
        if (err) res.send();
        else {
            r = r.concat(rows);
            conn.query("select count(*) as downvotes from votesOnComments where vote=-1 and commentid=?", [i], function(err, rows, fields){
                if (err) res.send();
                else {
                    r = r.concat(rows);
                    conn.query("select * from commentsOnComments where commentid=?", [i], function(err, rows, fields) {
                        r = r.concat([rows]);
                        res.send(r);
                    });
                }
            });
        }
    });
});

router.post('/user/book/comment/reply', function (req, res) {
    verifyProfile(req.signedCookies.user, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var commentid = req.body.commentid;
            var reply = req.body.reply;
            conn.query("insert into commentsOnComments (username, commentid, reply) values (?, ?, ?)", [username, commentid, reply], function (err, rows, fields) {
                if (err) {console.log(err); res.send(false);}
                else res.send(true);
            });
        } else res.send(false);
    });
});

router.post('/user/book/comment/vote', function (req, res) {
    verifyProfile(req.signedCookies.user, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var commentid = req.body.commentid;
            var vote = req.body.vote;
            if (vote === 1 || vote === -1 || vote === '1' || vote === '-1') {
                var id = username+'|&$&|'+commentid;
                conn.query('select * from votesOnComments where id=?', [id], function (err, rows, fields) {
                    if (rows.length == 0) {
                        conn.query("insert into votesOnComments (id, commentid, vote) values (?, ?, ?)", [id, commentid, vote], function (err, rows, fields) {
                            if (err) {console.log(err); res.send(false);}
                            else res.send(true);
                        });
                    } else {
                        conn.query("update votesOnComments set vote=? where id=?", [vote, id], function (err, rows, fields) {
                            if (err) {console.log(err); res.send(false);}
                            else res.send(true);
                        });
                    }
                });
                
            } else res.send(false);
        } else res.send(false);
    });
});






























module.exports = router
