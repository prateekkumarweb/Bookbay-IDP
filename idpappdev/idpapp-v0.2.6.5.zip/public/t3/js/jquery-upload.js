$(document).ready(function(){
    
    $("#upload-book").click(function(){
        $("#bk-file").slideUp();
        $("#bk-link").slideDown();
        $("#upbk-name").val("");
        $("#upbk-course").val("");
        $("#upbk-link").val("");
        $("#upbk-file").val("");
    });
    
    $("#enter-file").click(function(){
        $("#bk-link").slideUp();
        $("#bk-file").slideDown();
    });
    $("#enter-link").click(function(){
        $("#bk-file").slideUp();
        $("#bk-link").slideDown();
    });
    
    $("#up-bk-submit").click(function(){
        if(($("#upbk-name").val()=="") || ($("#upbk-course").val()=="") || (($("#upbk-link").val()=="") && ($("#upbk-file").val()==""))){
           $("#upbk-error").css('display','block');
           }
        else{
            $("#up-bk-submit").attr({'data-dismiss':"modal",'data-toggle':"modal",'data-target':"#upld-bk-thank"});
        }
                            
    });
    
});

// $("#up-bk-submit").attr('data-dismiss','modal');