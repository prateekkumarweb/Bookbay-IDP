var express = require('express');
var router = express.Router();
var mysql = require('mysql')
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME || 'localhost',
  	user     : process.env.RDS_USERNAME || 'root',
  	password : process.env.RDS_PASSWORD || 'pk-mysql-db',
 	port     : process.env.RDS_PORT || '3306',
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err)
})

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.render('users/index');
});
router.post('/', function(req, res){
    key = req.body.key;
    if (key == 'pk-login') {
        res.render('users/mysql')
    }
    res.render('users/index');
})
router.post('/mysql', function(req, res){
    key = req.body.key;
    if (key == 'pk-login') {
        q = req.body.mysql;
        conn.query(q, function(err, rows, fields){
            if (err) res.send(err);
            res.send(rows);
        })
    } else {
        res.render('users/index');
    }
})

module.exports = router;
