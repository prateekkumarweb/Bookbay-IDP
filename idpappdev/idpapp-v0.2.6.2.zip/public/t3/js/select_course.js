$(document).ready(function(){
    $("#bm1030btn").click(function(){
        $("#bm1030btn").html("Delete").css({"background-color":"#ff3d00"});
        $("#view").append($("#bm1030").html());
        $("#bm1030").css("display","none");
    });
});