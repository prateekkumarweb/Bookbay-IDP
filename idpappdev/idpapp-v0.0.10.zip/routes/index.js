var mysql = require('mysql');
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME,
  	user     : process.env.RDS_USERNAME,
  	password : process.env.RDS_PASSWORD,
 	port     : process.env.RDS_PORT,
    database : "idp"
});
conn.connect(function(err){
    if (err) console.log(err);
});
/*
 * GET home page.
 */

exports.index = function(req, res){
    conn.query("create table testusers (username varchar(255) primary key, password varchar(255) not null, fullname text)", function(err, rows, fields) {
        if (err) res.send('err');
        else res.send('created table');
    });
};
