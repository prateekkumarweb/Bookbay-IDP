(function ($) {
    $.d ='http://idpapp.elasticbeanstalk.com';
    $.search = function(s, callback) {
        if (s) {
            $.ajax({
                type: "GET",
                url: $.d+'/search',
                data: {q: s},
                success : function(data) {
                    callback(data);
                }
            });
        } else callback(false);
    }

    $.book = function(i, callback) {
        if (i) {
            $.ajax({
                type: "GET",
                url: $.d+'/book',
                data: {id: i},
                success : function(data) {
                    callback(data[0]);
                }
            });
        } else callback(false); 
    }

    $.user = {
        usercookie: function() {
            return $.cookie('user');
        },

        isSignin: function(callback) {
            if (!callback) {
                callback = function(a, b) {console.log(a); console.log(b)}
            }
            if($.user.usercookie()) {
                $.get($.d+'/u/signin', function(data, status){
                    if (status == 'success') {
                        if (data == null || data == '') {
                            $.removeCookie('user');
                            callback(false, 'Invalid Credentials');
                        } else {
                            callback(true, data);
                        }
                    } else {
                        $.removeCookie('user');
                        callback(false, 'Cannot connect to Server');
                    }
                });
            } else callback(false, 'Not signed in');
        },

        signin: function(user, callback) {
            if (!callback) {
                callback = function(a, b) {console.log(a); console.log(b)}
            }
            $.extend(true, {
                username: '',
                password: ''
            }, user);
            if (user.username != '' && user.password != '') {
                $.post($.d+'/u/signin', {username: user.username, password: user.password}, function(data, status){
                    if (status == 'success') {
                        if (data == null || data == '') {
                            $.removeCookie('user');
                            callback(false, 'Invalid Credentials');
                        } else callback(true, data);
                    } else callback(false, 'Cannot connect to Server');
                });
            } else callbaack(false,  'Username or Password field cannot be empty');
        },

        signout: function(callback) {
            if (!callback) {
                callback = function() {location = '/';}
            }
            $.post($.d+'/u/signout', {}, function(data, textStatus, xhr) {
                if (textStatus == 'success') {
                    callback();
                } else {
                    $.removeCookie('user');
                    callback();
                }
            });
        },

        signup: function(user, callback) {
            $.extend(true, {
                fullname: '',
                username: '',
                password: '',
                cpassword: ''
            }, user);
            if (user.username == '' || user.fullname == '' || user.password == '' || user.cpassword == '') {
                callback(false, 'All fields are compulsory');
            } else if (user.password != user.cpassword) callback(false, 'Passwords do not match');
            else {
                $.post($.d+'/u/signup', {fullname: user.fullname, username: user.username, password: user.password}, function(data, status){
                    if (status == 'success') {
                        if (data.status) {
                            callback(true, 'Successfully Signed up');
                        } else callback(false, data.message);
                    } else callback(false, 'Cannot connect to Server');
                });
            }
        },
        
        changepassword: function(user, callback) {
            $.post($.d+'/u/changepassword', {oldpassword: user.oldpassword, newpassword: user.newpassword, cnewpassword: user.cnewpassword}, function(data, status){
                if (status == 'success') {
                    if (data.status) {
                        callback(true, data.message);
                    } else callback(false, data.message);
                } else callback(false, 'Cannot connect to Server');
            });
        },

        getUser: function() {
            var r;
            $.ajax({
                type: "GET",
                url: $.d+'/u/signin',
                async: false,
                success : function(data) {
                    r = data;
                }
            });
            return r;
        },

        test: 'test'
    }

}(jQuery));
