var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var nodemailer = require("nodemailer");
var smtpTransport = nodemailer.createTransport("SMTP", {
    host: 'smtp.iith.co.in',
    port: 25,
    auth: {
        user: 'noreply@iith.co.in',
        pass: 'xrPY*p#1'
    }
});

var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME || 'localhost',
  	user     : process.env.RDS_USERNAME || 'root',
  	password : process.env.RDS_PASSWORD || 'pk-mysql-db',
 	  port     : process.env.RDS_PORT || '3306',
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err);
});

var common = require("./common");
function isSignin(user, callback) {
  common.signInStatus(user, conn, callback);
}

function sendEmail(toemail, sub, txt, htm, callback) {
    var mailOptions = {
        from: "Bookbay at IITH <noreply@iith.co.in>", // sender address
        to: toemail, // list of receivers
        subject: sub, // Subject line
        text: txt, // plaintext body
        html: htm // html body
    }
    smtpTransport.sendMail(mailOptions, function(error, response){
        if(error){
            console.log(error);
            callback(false);
        }else{
            console.log("Message sent: " + response.message);
            callback(true);
        }

        // if you don't want to use this transport object anymore, uncomment following line
        //smtpTransport.close(); // shut down the connection pool, no more messages
    });

}

//res.header("Access-Control-Allow-Origin", "*");




router.get('/signin', function(req, res){
    isSignin(req, function(status, user){
        if (status) {
            res.send(user);
        } else {
            res.clearCookie('user');
            res.send();
        }
    });
});

router.post('/signin', function(req, res){
    userDetails = [req.body.username, req.body.password];
    url = req.body.url;
    isSignin(userDetails, function(status, user){
        if (status) {
            res.cookie('user', common.encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
            res.redirect(url);
        } else {
            res.clearCookie('user');
            res.redirect(url);
        }
    });
})





router.post('/signup', function(req, res){
    if (req.signedCookies.user) {
        res.send({status: false, message: 'Signout first'});
    } else {
        var fullname = req.body.fullname;
        var username = req.body.username;
        var password = req.body.password;
        var rndm = common.generateRandomString();
        if (password != "" && fullname != "" && username != "" ) {
            var z = common.verifyUsername(username);
            if (z[0]) {
              conn.query("select * from userProfile where profilename=?", [z[1]], function(err, rows, fields){
                  if (err) {
                    console.log(err);
                    res.render('index', {type: 'signup', signedIn: false, user: [], message: 'There was a temperory error. Please try again later.'});
                    //res.send({status: false, message: err});
                  } else if (rows.length != 0) {
                    res.render('index', {type: 'signup', signedIn: false, user: [], message: 'User has already registered.'});
                    //res.send({status: false, message: 'User has already registered'});
                  } else {
                      conn.query("select * from users where username=?", [z[1]], function(err, rows, fields){
                        if (err) {
                          console.log(err);
                          res.render('index', {type: 'signup', signedIn: false, user: [], message: 'There was a temperory error. Please try again later.'});
                          //res.send({status: false, message: err});
                        } else if (rows.length === 0) {
                            conn.query("insert into users (fullname, username, password, verify) values (?, ?, ?, ?)", [fullname, z[1], common.hash(password), rndm], function(err){
                                if (err){
                                    console.log(err);
                                    res.render('index', {type: 'signup', signedIn: false, user: [], message: 'There was a temperory error. Please try again later.'});
                                    //res.send({status: false, message: err});
                                }
                                else {
                                    res.cookie('user', common.encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
                                    var t = "To verify your account go to http://lib.iith.co.in/u/verify/"+rndm+" ";
                                    var h = "<a href='http://lib.iith.co.in/u/verify/"+rndm+"'>Click here to verify Account</a>";
                                    sendEmail(z[1].toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(a){

                                    });
                                    res.render('index', {type: 'signupverify', signedIn: false, user: [], message: 'Username signed in'});
                                    //res.send({status: true, message: 'Username signed in'});
                                }
                            });
                        } else {
                            conn.query("update users set fullname=?,password=?,verify=? where username=?", [fullname, common.hash(password), rndm, z[1]], function(err){
                                if (err){
                                    console.log(err);
                                    res.render('index', {type: 'signup', signedIn: false, user: [], message: 'There was a temperory error. Please try again later.'});
                                    //res.send({status: false, message: err});
                                }
                                else {
                                    res.cookie('user', common.encrypt(req.body.username + 'username-password' + req.body.password), { signed: true });
                                    var t = "To verify your account go to http://lib.iith.co.in/u/verify/"+rndm+" ";
                                    var h = "<a href='http://lib.iith.co.in/u/verify/"+rndm+"'>Click here to verify Account</a>";
                                    sendEmail(z[1].toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(a){

                                    });
                                    res.render('index', {type: 'signupverify', signedIn: false, user: [], message: 'Username signed in'});
                                    //res.send({status: true, message: 'Username signed in'});
                                }
                            });
                        }
                      });






                  }
              });
            }
            else {
              res.render('index', {type: 'signup', signedIn: false, user: [], message: 'Only IITH emails are accepted.'});
              //  res.send({status: false, message: 'Only IITH emails are accepted'});
            }
        } else {
          res.render('index', {type: 'signup', signedIn: false, user: [], message: 'All fields are compulsory.'});
          //res.send({status: false, message: 'Passwords do not match'});
        }
    }
});

router.get('/verify/:r', function(req, res){
    var r = req.params.r;
    conn.query("select * from users where verify=?", [r], function(err, rows, fields){
        if (err) res.send("Couldnot verify user. There was a temperory error.");
        else {
            if (rows.length === 0) res.send(404);
            else {
                conn.query("insert into userProfile (profilename, fullname) values (?, ?)", [rows[0].username, rows[0].fullname], function(errr){
                    if (errr) res.redirect("/u/user");
                    else {
                        conn.query("update users set verify='verified' where verify=?", [r], function(){
                            res.send("You have successfully verified your email. <a href='/u/user'>Go to Home</a>");
                        });
                    }
                });
            }
        }
    });
});

router.post('/signout', function(req, res){
    res.clearCookie('user');
    res.send();
});

router.post('/changepassword', function(req, res){
    isSignin(req, function(status, user){
        if (status) {
            var oldpassword = req.body.oldpassword;
            var newpassword = req.body.newpassword;
            var cnewpassword = req.body.cnewpassword;
            if (newpassword != cnewpassword) {
                res.send({status: false, message: 'Passwords do not match'});
            } else if (common.hash(oldpassword) === user.password) {
                conn.query('UPDATE users SET password=? WHERE username=?', [common.hash(newpassword), user.username], function(err, rows, fields){
                    if (err) {
                        res.send({status: false, message: 'Try Again later'});
                    } else {
                        res.cookie('user', common.encrypt(user.username + 'username-password' + newpassword), { signed: true });
                        res.send({status: true, message: 'Password changed'});
                    }
                });
            } else {
                res.send({status: false, message: 'Invalid password'});
            }
        } else {
            res.send({status: false, message: 'User not signed in'});
        }
    });
});

router.post('/forgotpassword', function(req, res){
    //isSignin(req, function(a, user){
    a = false;
        if (a) res.send(false);
        else {
            var u = req.body.username;
            console.log(u);
            u = common.verifyUsername(u);
            console.log(u);
            s = u[0];
            console.log(s);
            if (s) {
                u = u[1];
                var rndm = common.generateRandomString();
                console.log(u);
                console.log(rndm);
                conn.query("UPDATE users SET verify=? WHERE username=?", [rndm, u], function(err, rows, fields){
                    if (err) res.send({status: false});
                    else {
                        var t = "To change your password go to http://lib.iith.co.in/u/forgotpassword/"+rndm+" ";
                        var h = "<a href='http://lib.iith.co.in/u/forgotpassword/"+rndm+"'>Click here to change your password</a>";
                        sendEmail(u+"@iith.ac.in", "Forgot password", t, h, function(a){
                            res.send({status: true});
                        });

                    }
                });
            } else res.send({status: false});
        }
    //});
});

router.get('/forgotpassword/:r', function(req, res){
    var r = req.params.r;
    conn.query("select * from users where verify=?", [r], function(err, rows, fields){
        if (err) res.send("Couldnot verify user. There was a temperory error.");
        else {
            if (rows.length === 0) res.send(404);
            else {
                res.send("Now you can change your password");
            }
        }
    });
});
/*router.get('/email',  function(req, res) {
    var mailOptions = {
        from: "Bookbay at IITH <noreply@bookbayatiith.com>", // sender address
        to: "Help <pksingh1023@gmail.com>", // list of receivers
        subject: "Hello", // Subject line
        text: "Hello world", // plaintext body
        html: "<b>Hello world</b>" // html body
    }
    smtpTransport.sendMail(mailOptions, function(error, response){
        if(error){
            console.log(error);
            res.send('failure');
        }else{
            console.log("Message sent: " + response.message);
            res.send('success');
        }

        // if you don't want to use this transport object anymore, uncomment following line
        //smtpTransport.close(); // shut down the connection pool, no more messages
    });
});*/

function verifyProfile(user, callback) {
    isSignin(user, function(status, us) {
        if(status) {
            conn.query("select * from userProfile where profilename=?", [us.username], function(err, rows, fields){
                if (err) callback(true, false, []);
                else if (rows.length === 0) callback(true, false, us);
                else {
                    callback(true, true, rows[0]);
                }
            });
        } else {
            callback(false, false, []);
        }
    });
}

//profile page scripts starts here
router.get('/user*', function(req, res, next) {
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    verifyProfile(req, function(a, b, user){
        if (a) {
            if (b) next();
            else res.render('index', {type: 'signupverify', signedIn: false, user: [], message: 'Username signed in'});
        } else res.render('index', {type: 'signin', signedIn: false, user: [], url: '/u' + encodeURI(req.url)});
    });
});

router.get('/vemail', function(req, res){
    verifyProfile(req, function(a, b, user){
        if (a) {
            if (b) res.send(false);
            else {
                var rndm = user.verify;
                var t = "To verify your account go to http://lib.iith.co.in/u/verify/"+rndm+" ";
                var h = "<a href='http://lib.iith.co.in/u/verify/"+rndm+"'>Click here to verify Account</a>";
                sendEmail(user.username.toLowerCase()+"@iith.ac.in", "Verification of Account at Bookbay", t, h, function(ab){
                    res.send(ab);
                });
            }
        } else res.send(false);
    });
});

router.post('/user*', function(req, res, next) {
    verifyProfile(req, function(a, b, user){
        if (a) {
            if (b) next();
            else res.send(false);
        } else res.send(false);
    });
});

router.get('/user', function(req, res){
    res.render('profile');
});
























router.get('/book/download/:id/book.pdf', function(req, res){
  var id = req.params.id;
  conn.query('select url from books where id=?', [id], function(err, rows, fields){
    if (err) res.send(404);
    else if (rows.length === 0) {
      res.send(404)
    }
    else {
      var http = require('http');
      var url = require('url');
      var l = rows[0].url;
      var link = url.parse(l);
      var options = {
        method: 'GET',
        host: link.host,
        port: 80,
        path: link.path
      };

      var request = http.request(options, function(response) {
        //var data='';
        var data = [];

        response.on('data', function(chunk) {
          //data += chunk;
          data.push(chunk);
        });

        response.on('end', function() {
          data = Buffer.concat(data); // do something with data
          //console.log(data.toString());
          if (req.signedCookies.user) {
              verifyProfile(req, function(a, b, user){
                  if (a && b) {
                      var username = user.profilename.toUpperCase();
                      var bookid = id;
                      conn.query("insert into bookdownloads (bookid, username) values (?, ?)", [bookid, username], function(err, rows, fields){
                          download();
                      });
                  } else download();
              });
          } else download();
          function download() {
            if (data == '') res.redirect(l);
            else {
              res.header('content-type', 'application/pdf');
              res.header('content-disposition', 'attachment');
              res.send(data);
            }
          }

        });
      });

      request.end();

    }
  });

});

router.get('/user/books/recent', function(req, res){
  verifyProfile(req, function(a, b, user){
      if (a && b) {
          conn.query('select bookdownloads.*, books.pic from bookdownloads inner join books on bookdownloads.bookid=books.id where bookdownloads.username=? order by id desc', [user.username || user.profilename], function(err, rows, fields){
            if (err) res.send();
            else res.send(rows);
          });
      } else res.send();
  });
});

router.post('/user/book/comment', function (req, res) {
    verifyProfile(req, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var bookid = req.body.bookid;
            var comment = req.body.comment;
            conn.query("insert into commentsOnBooks (username, bookid, comment) values (?, ?, ?)", [username, bookid, comment], function (err, rows, fields) {
                if (err) {console.log(err); res.send(false);}
                else res.send(true);
            });
        } else res.send(false);
    });
});

router.get('/book/comments', function (req, res) {
    var i = req.query.bookid;
    conn.query("select commentsOnBooks.*, users.fullname from commentsOnBooks inner join users on commentsOnBooks.username=users.username where commentsOnBooks.bookid=? order by commentsOnBooks.id DESC", [i], function(err, rows, fields){
        if (err) res.send();
        else res.send(rows);
    });
});

router.get('/book/comment/votesandreplies', function (req, res) {
    var i = req.query.commentid;
    var r = [];
    conn.query("select count(*) as upvotes from votesOnComments where vote=1 and commentid=?", [i], function(err, rows, fields){
        if (err) res.send();
        else {
            r = r.concat(rows);
            conn.query("select count(*) as downvotes from votesOnComments where vote=-1 and commentid=?", [i], function(err, rows, fields){
                if (err) res.send();
                else {
                    r = r.concat(rows);
                    conn.query("select * from commentsOnComments where commentid=?", [i], function(err, rows, fields) {
                        r = r.concat([rows]);
                        res.send(r);
                    });
                }
            });
        }
    });
});

router.post('/user/book/comment/reply', function (req, res) {
    verifyProfile(req, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var commentid = req.body.commentid;
            var reply = req.body.reply;
            conn.query("insert into commentsOnComments (username, commentid, reply) values (?, ?, ?)", [username, commentid, reply], function (err, rows, fields) {
                if (err) {console.log(err); res.send(false);}
                else res.send(true);
            });
        } else res.send(false);
    });
});

router.post('/user/book/comment/vote', function (req, res) {
    verifyProfile(req, function (a, b, user) {
        if (a && b) {
            var username = user.profilename.toUpperCase();
            var commentid = req.body.commentid;
            var vote = req.body.vote;
            if (vote === 1 || vote === -1 || vote === '1' || vote === '-1') {
                var id = username+'|&$&|'+commentid;
                conn.query('select * from votesOnComments where id=?', [id], function (err, rows, fields) {
                    if (rows.length == 0) {
                        conn.query("insert into votesOnComments (id, commentid, vote) values (?, ?, ?)", [id, commentid, vote], function (err, rows, fields) {
                            if (err) {console.log(err); res.send(false);}
                            else res.send(true);
                        });
                    } else {
                        conn.query("update votesOnComments set vote=? where id=?", [vote, id], function (err, rows, fields) {
                            if (err) {console.log(err); res.send(false);}
                            else res.send(true);
                        });
                    }
                });

            } else res.send(false);
        } else res.send(false);
    });
});




// Add book in database

router.get('/addbook', function(req, res){
  verifyProfile(req, function(a, b, user){
    if (a && b) {
      var admin = ['CS15BTECH11031', 'CS15BTECH11018'];
      var username = user.profilename.toUpperCase();
      if (admin.indexOf(username) === -1) res.send(403);
      else {
        res.render('u/book');
      }
    } else res.send(403);
  });
});


router.post('/addbook', function(req, res){
  verifyProfile(req, function(a, b, user){
    if (a && b) {
      var admin = ['CS15BTECH11031', 'CS15BTECH11018'];
      var username = user.profilename.toUpperCase();
      if (admin.indexOf(username) === -1) res.send(403);
      else {
        var id=Date.now();
        var name=req.body.name;
        var author=req.body.author;
        var description=req.body.description;
        var course=req.body.course.toUpperCase();
        var url=req.body.url;
        var pic=req.body.pic;
        var userWhoAdded=username;
        conn.query('insert into courses (id, name, start, end) values (?, ?, ?, ?)', [course, course, '2015-07-28', '2020-12-31'], function(err){
          if (err) console.log(err);
          conn.query('insert into books (id, name, author, course, description, url, pic, userWhoAdded) values (?, ?, ?, ?, ?, ?, ?, ?)', [id, name, author, course, description, url, pic, userWhoAdded], function(err){
            if (err) {
              console.log(err);
              res.send('Book could not be added. Try again.');
            }
            else res.send('Book successfully added');
          });
        });
        //res.send(username);
      }
    } else res.send(403);
  });
});





















module.exports = router
