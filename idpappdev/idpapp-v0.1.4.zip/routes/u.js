var express = require('express')
var router = express.Router()
var mysql = require('mysql')
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME || 'localhost',
  	user     : process.env.RDS_USERNAME || 'root',
  	password : process.env.RDS_PASSWORD || 'pk-mysql-db',
 	port     : process.env.RDS_PORT || '3306',
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err)
})

function signin(user, callback) {
    conn.query("select * from users where username=? and password=?", [user[0], user[1]], function(err, rows, fields){
        if (err) {
            callback(false, [])
        }
        else if (!rows[0]) {
            callback(false, [])
        }
        else {
            u = {}
            for (var i in rows[0]) {
                u[i] = rows[0][i]
            }
            callback(true, u)
        }
    })
}

router.get('/*', function(req, res, next){
    conn.query("create table if not exists users (username varchar(255) primary key, password varchar(255) not null, fullname text not null)", function(err, rows, fields){
        if (err) res.send(err);
    })
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    next(); 
});

router.get('/', function(req, res) {
    if (req.signedCookies.user) {
        var userCookie = req.signedCookies.user
        userDetails = userCookie.split('username|password')
        signin(userDetails, function(status, user){
            if (status) {
                //console.log(us['fullname'])
                res.render('u/index', {u: user})
            } else {
                res.clearCookie('user')
                res.render('u/signin', { message: '', username: '', password: '' })
            }
        })
    }
    else {
        res.render('u/signin', { message: '', username: '', password: '' })
    }
})

router.get('/signinwithjs', function(req, res){
    if (req.signedCookies.user) {
        var userCookie = req.signedCookies.user
        userDetails = userCookie.split('username|password')
        signin(userDetails, function(status, user){
            if (status) {
                res.send(user)
            } else {
                res.clearCookie('user')
                res.send()
            }
        })
    }
    else {
        res.send()
    }
})

router.get('/signin', function(req, res){
    if (!req.signedCookies.user) {
        res.render('u/signin', { message: '', username: '', password: '' })
    } else {
        res.writeHead(301, {
            Location: '/u'
        })
        res.end()
    }
})

router.post('/signin', function(req, res){
    if (req.signedCookies.user) {
        res.writeHead(301, {
            Location: '/u'
        })
        res.end()
    }
    conn.query("select * from users where username=?", [req.body.username], function(err, rows, fields){
        if (err){
            res.render('u/signin', { message: 'There was an error. Try again later.', username: req.body.username, password: req.body.password })
        }
        else if (!rows[0]) {
            res.render('u/signin', { message: 'Username not found.', username: req.body.username, password: req.body.password })
        }
        else if (rows[0]['password'] != req.body.password) {
            res.render('u/signin', { message: 'Incorrect Password.', username: req.body.username, password: req.body.password })
        }
        else {
            res.cookie('user', req.body.username + 'username|password' + req.body.password, {
                signed: true
            })
            res.writeHead(301, {
                Location: '/u'
            })
            res.end()
        }
    })
})

router.get('/signout', function(req, res){
    if (req.cookies.signout == 'signout') {
        res.clearCookie('user')
        res.clearCookie('signout')
        res.render('u/signin', { message: 'Signed out successfully.', username: '', password: '' })
    }
    else {
        res.sendStatus(404)
    }
})

router.get('/signup', function(req, res){
    if (!req.signedCookies.user) {
        res.render('u/signup', { message: '' })
    } else {
        res.writeHead(301, {
            Location: '/u'
        })
        res.end()
    }
})

router.post('/signup', function(req, res){
    if (req.signedCookies.user) {
        res.writeHead(301, {
            Location: '/u'
        })
        res.end()
    } else {
        var fullname = req.body.fullname
        var username = req.body.username
        var password = req.body.password
        var cpassword = req.body.cpassword
        if (password == cpassword && password != "" && fullname != "" && username != "" ) {
            conn.query("insert into users (fullname, username, password) values (?, ?, ?)", [fullname, username, password], function(err){
                if (err){
                    res.render('u/signup', { message: 'username is already in use.' })
                }
                else {
                    res.cookie('user', req.body.username + 'username|password' + req.body.password, {
                        httpOnly: true,
                        signed: true
                    })
                    res.writeHead(301, {
                        Location: '/u'
                    })
                    res.end()
                }
            })
        } else {
            res.render('u/signup', { message: 'Error occured.' })
        }
    }
})


module.exports = router
