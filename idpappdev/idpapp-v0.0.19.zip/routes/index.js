var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var conn = mysql.createConnection({
  	host     : process.env.RDS_HOSTNAME,
  	user     : process.env.RDS_USERNAME,
  	password : process.env.RDS_PASSWORD,
 	port     : process.env.RDS_PORT,
    database : 'idp'
});
conn.connect(function(err){
    if (err) console.log(err);
});

/* GET home page. */
router.get('/', function(req, res, next) {
    conn.query("create table if not exixts books (id varchar(255) primary key, name varchar(255) not null, author varchar(255), course varchar(255), description text, url text, fulltext (id, name, author, course))", function(err, rows, fields){
        if (err) res.send(err)
    })
    res.render('index');
});

router.get('/book/:id', function(req, res) {
    var id = req.params.id;
    conn.query("select * from books where id='"+id+"';", function(err, rows, fields){
        res.render('book', {b: rows});
    })
});

router.get('/search', function(req, res) {
    var q = req.query.q;
    conn.query("select * from books where match (id, name, author, course) against (? in natural language mode)",[q] , function(err, rows, fields) {
        res.render('search', {s: rows, q : q});
    });    
});


module.exports = router;
