$(document).ready(function(){

    $("#search-bar").focus(function(){
        $("#search-bar").animate({width: '200%'});
        $("#search-btn").animate({marginLeft:'153px'});
       // $("#search-bar-btn").animate({marginLeft:'153px'});
    });

    $("#search-bar").blur(function(){
        $("#search-bar").animate({width: '100%'});
        $("#search-btn").animate({marginLeft:'0px'});
      //  $("#search-bar-btn").animate({marginLeft:'0px'});
    });


    $("#signup,#login").click(function(){
        $("#username,#password,#name,#email,#spassword,#scpassword").val("");
        $("#invalidcr,#pname,#pemail,#pspassword,#pscpassword,#mismatch").html("");
        $("#cnfEmail,#cnfPassword").removeClass("has-success has-error");
        $("#cnfEmailOK,#cnfPasswordOK").removeClass("glyphicon-ok glyphicon-remove");
    });

    //Sign up
     $("#finalsup").click(function(){
         mail=$("#email").val()
         n=mail.length;
         if (($("#name").val()=="")||($("#email").val()=="")||($("#spassword").val()=="")||($("#scpassword").val()=="")){
            if($("#name").val()==""){
                $("#pname").html("This cannot be empty");
            }

            if($("#email").val()==""){
                $("#pemail").html("This cannot be empty");
            }

            if($("#spassword").val()==""){
                $("#pspassword").html("This cannot be empty");
            }

            if($("#scpassword").val()==""){
                $("#pscpassword").html("This cannot be empty");
            }
         }
         else if (mail.slice(n-11,n)!="@iith.ac.in"){
             $("#pemail").html("Only IITH email-id is allowed");
         }
         else if ($("#spassword").val()!=$("#scpassword").val()){
                $("#mismatch").html("Passwords didn't match");
         }
         else{
            //$login1.slideDown(550);
            //signup1.slideUp();
            $("#username,#password").val("");
            $("#loginnote").html("<b>Now you can log into your account</b>")
         }
    });

    //Signup
    (function(){
        $("#name").on("blur keyup",function(){
            if ($(this).val()==""){
                $("#pname").html("This cannot be empty");
            }
            else{
                $("#pname").html("");
            }
        });

        $("#email").on("blur keyup",function(){
            if ($(this).val()==""){
                $("#pemail").html("This cannot be empty");
            }
            else{
                $("#pemail").html("");
            }
        });

        $("#spassword").on("blur keyup",function(){
            if ($(this).val()==""){
                $("#pspassword").html("This cannot be empty");
            }
            else{
                $("#pspassword").html("");
            }
        });

        $("#scpassword").on("blur keyup",function(){
            if ($(this).val()==""){
                $("#pscpassword").html("This cannot be empty");
            }
            else{
                $("#pscpassword").html("");
            }
        });
    })();

    (function(){
        function cnfPassword(){
        if($("#spassword").val()!=$("#scpassword").val()){
            $("#cnfPassword").removeClass("has-success").addClass("has-error");
            $("#cnfPasswordOK").removeClass("glyphicon-ok").addClass("glyphicon-remove");
        }
        else{
            $("#cnfPassword").removeClass("has-error").addClass("has-success");
            $("#cnfPasswordOK").removeClass("glyphicon-remove").addClass("glyphicon-ok");
        }
    }
        $("#spassword,#scpassword").keyup(function(){
            cnfPassword();
        });
    })();

    (function(){
        function cnfEmail(){
            mail=$("#email").val()
            n=mail.length;
        if(mail.slice(n-11,n)!="@iith.ac.in"){
            $("#cnfEmail").removeClass("has-success").addClass("has-error");
            $("#cnfEmailOK").removeClass("glyphicon-ok").addClass("glyphicon-remove");
        }
        else{
            $("#cnfEmail").removeClass("has-error").addClass("has-success");
            $("#cnfEmailOK").removeClass("glyphicon-remove").addClass("glyphicon-ok");
        }
    }
        $("#email").keyup(function(){
            cnfEmail();
        });
    })();

    (function(){
        $("#llogin").click(function(){
            if (($("#username").val()=="")||($("#password").val()=="")){
            $("#invalidcr").html("Invalid Credentials");
            }
            else{
                $("#invalidcr").html("");
                var c=1;
            }

            if (c==1){
                $(this).addClass('disabled');
                //window.open("profile.html","_self");
            }
        });
    })();

    /* for comments */
    /*$("#comment").focus(function(){
        $("#first").css("display","block");
        $("#aa").attr("href","#first");
    });*/
    $("#cname").focus(function(){
        $("#second").slideDown();
    });

    // For Login
    (function(){
        $("#clogin").click(function(){
            if (($("#cusername").val()=="")||($("#cpassword").val()=="")){
            $("#cinvalidcr").html("Invalid Credentials");
            }
            else{
                $("#cinvalidcr").html("");
                var c=1;
            }

            if (c==1){
                window.open("book.html","_self");
            }
        })
    })();

    // For Signup
    (function(){
        $("#cname").blur(function(){
            if ($(this).val()==""){
                $("#pcname").html("This cannot be empty");
            }
            else{
                $("#pcname").html("");
            }
        });

        $("#cemail").blur(function(){
            if ($(this).val()==""){
                $("#pcemail").html("This cannot be empty");
            }
            else{
                $("#pcemail").html("");
            }
        });

        $("#cspassword").blur(function(){
            if ($(this).val()==""){
                $("#pcspassword").html("This cannot be empty");
            }
            else{
                $("#pcspassword").html("");
            }
        });

        $("#cscpassword").blur(function(){
            if ($(this).val()==""){
                $("#pcscpassword").html("This cannot be empty");
            }
            else{
                $("#pcscpassword").html("");
            }
        });

        $("#csignup").click(function(){
         mail=$("#cemail").val()
         n=mail.length;
         if (($("#cname").val()=="")||($("#cemail").val()=="")||($("#cspassword").val()=="")||($("#cscpassword").val()=="")){
            if($("#cname").val()==""){
                $("#pcname").html("This cannot be empty");
            }

            if($("#cemail").val()==""){
                $("#pcemail").html("This cannot be empty");
            }

            if($("#cspassword").val()==""){
                $("#pcspassword").html("This cannot be empty");
            }

            if($("#cscpassword").val()==""){
                $("#pcscpassword").html("This cannot be empty");
            }
         }
         else if (mail.slice(n-11,n)!="@iith.ac.in"){
             $("#pcemail").html("Only IITH email-id is allowed");
         }
         else if ($("#cspassword").val()!=$("#cscpassword").val()){
                $("#cmismatch").html("Passwords didn't match");
         }
         else{
            window.open("book.html","_self");
         }
    });
    })();

    // rating of the comments
    
    /* for comments */
});
